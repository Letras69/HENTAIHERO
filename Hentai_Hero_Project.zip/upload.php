
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $videoFile = $target_dir . basename($_FILES["video"]["name"]);
    $imageFile = $target_dir . basename($_FILES["imagen"]["name"]);

    if (move_uploaded_file($_FILES["video"]["tmp_name"], $videoFile) &&
        move_uploaded_file($_FILES["imagen"]["tmp_name"], $imageFile)) {
        echo "Archivos subidos con éxito.<br>";
        echo "Video: <a href='$videoFile'>$videoFile</a><br>";
        echo "Imagen: <a href='$imageFile'>$imageFile</a>";
    } else {
        echo "Error al subir los archivos.";
    }
}
?>
